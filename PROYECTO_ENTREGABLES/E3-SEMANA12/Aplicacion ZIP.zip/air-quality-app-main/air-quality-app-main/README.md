# Monitor de Calidad del Aire — UNFV 2026
**ESP32 + SDS011 + MQ-135 | Python Flask | MVC + Login y Roles**

---

## Estructura del proyecto

```
air-quality-app/
│
├── app.py                          ← Punto de entrada Flask
├── config.py                       ← Configuración global (rutas, umbrales, modo)
│
├── controllers/
│   ├── auth_controller.py          ← Login, logout, decoradores de sesión
│   ├── sensor_controller.py        ← Dashboard, recepción de datos del ESP32
│   ├── admin_controller.py         ← Umbrales, usuarios, reinicio de historial
│   └── historial_controller.py     ← Vista e API de historial
│
├── model/
│   ├── database.py                 ← Conexión SQLite + creación de tablas
│   ├── air_quality.py              ← Clasificación de calidad del aire
│   ├── usuario.py                  ← Autenticación y gestión de usuarios
│   ├── umbrales.py                 ← Lectura/escritura de umbrales
│   └── historial.py                ← Persistencia del historial de lecturas
│
├── view/
│   └── templates/
│       ├── login.html
│       ├── dashboard.html
│       ├── historial.html
│       ├── recomendaciones.html
│       ├── admin.html
│       └── _navbar.html            ← Barra de navegación reutilizable
│
├── static/
│   ├── css/
│   │   ├── style.css
│   │   ├── login.css
│   │   └── admin.css
│   └── js/
│       ├── dashboard.js
│       ├── historial.js
│       └── admin.js
│
├── mock/
│   └── mock_sensor.py              ← Simulador del ESP32 (solo desarrollo)
│
├── data/
│   └── airquality.db               ← Base de datos SQLite (se crea sola)
│
├── requirements.txt
└── README.md
```

---

## Instalación

```bash
cd air-quality-app

python -m venv venv
venv\Scripts\activate        # Windows
source venv/bin/activate     # Mac/Linux

pip install -r requirements.txt

python app.py
```

Abrir en el navegador: **http://localhost:5000**
Desde el celular (misma WiFi): **http://TU_IP_LOCAL:5000**

La base de datos `data/airquality.db` se crea automáticamente la primera vez,
junto con los umbrales por defecto y un usuario administrador.

---

## Login y roles

Al iniciar por primera vez se crea un usuario administrador:

| Usuario | Contraseña | Rol   |
|---------|------------|-------|
| admin   | admin123   | admin |

**Cambia esta contraseña** desde el panel de administración (crea un nuevo
admin con tu contraseña y elimina o reemplaza el usuario `admin` por defecto,
o usa `Usuario.cambiar_password` desde una consola Python).

### Usuario normal — funciones
- Ver datos en tiempo real (Dashboard)
- Ver estado del aire (badges Bueno / Moderado / Dañino)
- Ver historial de lecturas
- Ver recomendaciones de salud
- Recibir alertas visuales (panel de alerta general)

### Administrador — funciones
- Modificar umbrales de PM2.5, PM10 y MQ-135
- Ver todos los registros del historial (`/api/historial-completo`)
- Gestionar usuarios (crear / eliminar)
- Reiniciar historial completo

Las rutas `/admin/*` están protegidas con el decorador `@admin_requerido`
(`controllers/auth_controller.py`); las demás vistas requieren `@login_requerido`.
El endpoint `/sensor-data` (usado por el ESP32) **no** requiere sesión.

---

## Modos de operación

### Modo desarrollo (sin ESP32)
En `config.py`, `MODO_MOCK = True` activa `mock/mock_sensor.py`, que envía
datos simulados cada 2 segundos a `/sensor-data`.

### Modo producción (con ESP32 real)
1. Cambiar `MODO_MOCK = False` en `config.py`.
2. El ESP32 debe enviar un `POST /sensor-data` con este JSON:

```json
{
  "pm25": 35.4,
  "pm10": 67.2,
  "mq135": 1823
}
```

**Código Arduino para el ESP32 (básico):**
```cpp
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

const char* ssid     = "TU_WIFI";
const char* password = "TU_CLAVE";
const char* servidor = "http://IP_DE_TU_PC:5000/sensor-data";

void enviarDatos(float pm25, float pm10, int mq135) {
  HTTPClient http;
  http.begin(servidor);
  http.addHeader("Content-Type", "application/json");

  StaticJsonDocument<200> doc;
  doc["pm25"]  = pm25;
  doc["pm10"]  = pm10;
  doc["mq135"] = mq135;

  String body;
  serializeJson(doc, body);
  http.POST(body);
  http.end();
}
```

---

## Rutas principales

| Método | Ruta                      | Protección       | Descripción                              |
|--------|---------------------------|-------------------|-------------------------------------------|
| GET/POST | `/login`                | pública           | Inicio de sesión                          |
| GET    | `/logout`                 | sesión            | Cierra sesión                             |
| GET    | `/` , `/dashboard`        | login             | Dashboard en tiempo real                  |
| GET    | `/historial`              | login             | Vista de historial + gráfico              |
| GET    | `/recomendaciones`        | login             | Recomendaciones de salud                  |
| GET    | `/admin`                  | admin             | Panel de administración                   |
| POST   | `/sensor-data`            | pública (ESP32)   | Recibe lecturas del sensor                |
| GET    | `/api/estado`             | login             | Estado actual (polling)                   |
| GET    | `/api/historial`          | login             | Últimas N lecturas                        |
| GET    | `/api/historial-completo` | admin            | Todos los registros                       |
| POST   | `/admin/umbrales`         | admin             | Actualiza umbrales                        |
| POST   | `/admin/usuarios`         | admin             | Crea un usuario                           |
| POST   | `/admin/usuarios/<id>/eliminar` | admin       | Elimina un usuario                        |
| POST   | `/admin/historial/reiniciar` | admin          | Borra el historial                        |

---

## Métricas implementadas

1. **Tiempo de respuesta de alerta** — desde que llega el dato hasta que aparece en pantalla (~2s)
2. **Tiempo de actualización** — ciclo de polling configurado en 2000ms
3. **Sensibilidad de detección** — clasificación por umbrales configurables (OMS / estándares peruanos)
4. **Nivel de gases MQ-135** — escala ADC 0–4095 con 3 niveles

---

## Plan de continuidad

- **IoT:** Reemplazar polling local con MQTT hacia Firebase/AWS IoT; los roles
  de usuario permitirían exponer dashboards multiusuario en la nube.
- **IA:** Exportar historial desde `data/airquality.db` (tabla `historial`) →
  entrenar modelo de predicción con TensorFlow Lite para anticipar picos de
  contaminación y generar alertas predictivas.
