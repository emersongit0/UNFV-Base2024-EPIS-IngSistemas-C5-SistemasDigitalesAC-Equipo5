from model.database import get_db
from werkzeug.security import generate_password_hash, check_password_hash


class Usuario:

    def __init__(self, id, username, rol, creado_en=None):
        self.id = id
        self.username = username
        self.rol = rol
        self.creado_en = creado_en

    @property
    def es_admin(self):
        return self.rol == "admin"

    # ──────────────────────────────────────────
    # Autenticación
    # ──────────────────────────────────────────
    @staticmethod
    def autenticar(username, password):
        """
        Verifica usuario/clave.
        Retorna un objeto Usuario si es válido, o None si no.
        """
        conn = get_db()
        fila = conn.execute(
            "SELECT * FROM usuarios WHERE username = ?", (username,)
        ).fetchone()
        conn.close()

        if fila is None:
            return None

        if not check_password_hash(fila["password_hash"], password):
            return None

        return Usuario(fila["id"], fila["username"], fila["rol"], fila["creado_en"])

    # ──────────────────────────────────────────
    # Consultas
    # ──────────────────────────────────────────
    @staticmethod
    def obtener_por_id(user_id):
        conn = get_db()
        fila = conn.execute(
            "SELECT * FROM usuarios WHERE id = ?", (user_id,)
        ).fetchone()
        conn.close()

        if fila is None:
            return None
        return Usuario(fila["id"], fila["username"], fila["rol"], fila["creado_en"])

    @staticmethod
    def listar_todos():
        """Retorna todos los usuarios (sin el hash de password) para el panel admin."""
        conn = get_db()
        filas = conn.execute(
            "SELECT id, username, rol, creado_en FROM usuarios ORDER BY id"
        ).fetchall()
        conn.close()
        return [dict(f) for f in filas]

    # ──────────────────────────────────────────
    # Gestión (solo administrador)
    # ──────────────────────────────────────────
    @staticmethod
    def crear(username, password, rol="usuario"):
        """
        Crea un nuevo usuario.
        Retorna (True, "ok") o (False, "mensaje de error").
        """
        username = username.strip()

        if not username or not password:
            return False, "Usuario y contraseña son obligatorios."

        if rol not in ("usuario", "admin"):
            return False, "Rol inválido."

        conn = get_db()
        existe = conn.execute(
            "SELECT 1 FROM usuarios WHERE username = ?", (username,)
        ).fetchone()

        if existe:
            conn.close()
            return False, "Ese nombre de usuario ya existe."

        conn.execute(
            "INSERT INTO usuarios (username, password_hash, rol) VALUES (?, ?, ?)",
            (username, generate_password_hash(password), rol),
        )
        conn.commit()
        conn.close()
        return True, "Usuario creado correctamente."

    @staticmethod
    def eliminar(user_id):
        """
        Elimina un usuario por id.
        Evita borrar al último administrador para no dejar el sistema sin acceso.
        """
        conn = get_db()

        objetivo = conn.execute(
            "SELECT rol FROM usuarios WHERE id = ?", (user_id,)
        ).fetchone()

        if objetivo is None:
            conn.close()
            return False, "Usuario no encontrado."

        if objetivo["rol"] == "admin":
            total_admins = conn.execute(
                "SELECT COUNT(*) AS total FROM usuarios WHERE rol = 'admin'"
            ).fetchone()["total"]
            if total_admins <= 1:
                conn.close()
                return False, "No se puede eliminar al único administrador."

        conn.execute("DELETE FROM usuarios WHERE id = ?", (user_id,))
        conn.commit()
        conn.close()
        return True, "Usuario eliminado."

    @staticmethod
    def cambiar_password(user_id, nueva_password):
        conn = get_db()
        conn.execute(
            "UPDATE usuarios SET password_hash = ? WHERE id = ?",
            (generate_password_hash(nueva_password), user_id),
        )
        conn.commit()
        conn.close()
        return True, "Contraseña actualizada."

    @staticmethod
    def cambiar_rol(user_id, nuevo_rol):
        """
        Cambia el rol de un usuario ('usuario' <-> 'admin').
        Evita degradar al último administrador del sistema.
        """
        if nuevo_rol not in ("usuario", "admin"):
            return False, "Rol inválido."

        conn = get_db()

        objetivo = conn.execute(
            "SELECT rol FROM usuarios WHERE id = ?", (user_id,)
        ).fetchone()

        if objetivo is None:
            conn.close()
            return False, "Usuario no encontrado."

        if objetivo["rol"] == "admin" and nuevo_rol == "usuario":
            total_admins = conn.execute(
                "SELECT COUNT(*) AS total FROM usuarios WHERE rol = 'admin'"
            ).fetchone()["total"]
            if total_admins <= 1:
                conn.close()
                return False, "No se puede quitar el rol al único administrador."

        conn.execute(
            "UPDATE usuarios SET rol = ? WHERE id = ?", (nuevo_rol, user_id)
        )
        conn.commit()
        conn.close()
        return True, "Rol actualizado correctamente."
