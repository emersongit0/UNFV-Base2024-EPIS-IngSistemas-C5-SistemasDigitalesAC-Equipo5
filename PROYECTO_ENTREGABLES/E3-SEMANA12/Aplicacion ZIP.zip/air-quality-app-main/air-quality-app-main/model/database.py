import sqlite3
import os
from config import DB_PATH, UMBRALES_DEFAULT, ADMIN_DEFAULT
from werkzeug.security import generate_password_hash


def get_db():
    """
    Crea una conexión nueva a la base de datos.
    row_factory permite acceder a las columnas por nombre
    (ej. fila["pm25"]) en vez de por índice.
    """
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    """
    Crea las tablas si no existen y siembra datos iniciales
    (umbrales por defecto y usuario administrador).
    Se llama una sola vez al iniciar app.py.
    """
    conn = get_db()
    cur = conn.cursor()

    # ── Tabla de usuarios ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS usuarios (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            rol TEXT NOT NULL DEFAULT 'usuario',
            creado_en TEXT DEFAULT (datetime('now', 'localtime'))
        )
    """)

    # ── Tabla de umbrales (clave / valor) ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS umbrales (
            clave TEXT PRIMARY KEY,
            valor REAL NOT NULL
        )
    """)

    # ── Tabla de historial de lecturas ──
    cur.execute("""
        CREATE TABLE IF NOT EXISTS historial (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TEXT DEFAULT (datetime('now', 'localtime')),
            pm25 REAL NOT NULL,
            pm10 REAL NOT NULL,
            mq135 INTEGER NOT NULL,
            estado TEXT NOT NULL
        )
    """)

    conn.commit()

    cur.execute("SELECT COUNT(*) AS total FROM umbrales")
    if cur.fetchone()["total"] == 0:
        for clave, valor in UMBRALES_DEFAULT.items():
            cur.execute(
                "INSERT INTO umbrales (clave, valor) VALUES (?, ?)",
                (clave, valor),
            )
        conn.commit()

    cur.execute("SELECT COUNT(*) AS total FROM usuarios WHERE rol = 'admin'")
    if cur.fetchone()["total"] == 0:
        cur.execute(
            "INSERT INTO usuarios (username, password_hash, rol) VALUES (?, ?, ?)",
            (
                ADMIN_DEFAULT["username"],
                generate_password_hash(ADMIN_DEFAULT["password"]),
                ADMIN_DEFAULT["rol"],
            ),
        )
        conn.commit()
        print(f"[init_db] Usuario admin creado -> "
              f"usuario: {ADMIN_DEFAULT['username']} | "
              f"clave: {ADMIN_DEFAULT['password']} (cámbiala luego)")

    conn.close()
