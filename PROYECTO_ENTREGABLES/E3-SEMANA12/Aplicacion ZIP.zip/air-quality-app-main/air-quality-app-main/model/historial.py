from model.database import get_db
from config import MAX_HISTORIAL


class Historial:

    @staticmethod
    def guardar(pm25, pm10, mq135, estado):
        """Inserta una nueva fila en el historial."""
        conn = get_db()
        conn.execute(
            "INSERT INTO historial (pm25, pm10, mq135, estado) VALUES (?, ?, ?, ?)",
            (pm25, pm10, mq135, estado),
        )
        conn.commit()
        conn.close()

    @staticmethod
    def obtener_recientes(limite=None):
        """
        Retorna las últimas `limite` lecturas (más reciente al final,
        ideal para graficar). Si limite es None, usa MAX_HISTORIAL.
        """
        if limite is None:
            limite = MAX_HISTORIAL

        conn = get_db()
        filas = conn.execute(
            "SELECT * FROM historial ORDER BY id DESC LIMIT ?",
            (limite,),
        ).fetchall()
        conn.close()

        return [dict(f) for f in reversed(filas)]

    @staticmethod
    def obtener_todos():
        """Retorna TODOS los registros (uso exclusivo del administrador)."""
        conn = get_db()
        filas = conn.execute(
            "SELECT * FROM historial ORDER BY id DESC"
        ).fetchall()
        conn.close()
        return [dict(f) for f in filas]

    @staticmethod
    def limpiar():
        """Elimina todos los registros del historial (acción de administrador)."""
        conn = get_db()
        conn.execute("DELETE FROM historial")
        conn.commit()
        conn.close()

    @staticmethod
    def contar():
        """Retorna el número total de registros guardados."""
        conn = get_db()
        total = conn.execute("SELECT COUNT(*) AS total FROM historial").fetchone()["total"]
        conn.close()
        return total
