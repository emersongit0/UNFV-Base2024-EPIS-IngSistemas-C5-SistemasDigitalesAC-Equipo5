from model.database import get_db


class Umbrales:
    """Acceso a la tabla `umbrales` (clave/valor)."""

    @staticmethod
    def obtener_todos():
        """Retorna un diccionario {clave: valor} con todos los umbrales."""
        conn = get_db()
        filas = conn.execute("SELECT clave, valor FROM umbrales").fetchall()
        conn.close()
        return {fila["clave"]: fila["valor"] for fila in filas}

    @staticmethod
    def actualizar(nuevos_valores: dict):

        # Generar automáticamente los valores dañinos
        nuevos_valores["pm25_dañino"] = nuevos_valores["pm25_moderado"]
        nuevos_valores["pm10_dañino"] = nuevos_valores["pm10_moderado"]
        nuevos_valores["mq135_dañino"] = nuevos_valores["mq135_moderado"]

        conn = get_db()
        cur = conn.cursor()

        for clave, valor in nuevos_valores.items():

            cur.execute(
                "UPDATE umbrales SET valor = ? WHERE clave = ?",
                (float(valor), clave),
            )

        conn.commit()
        conn.close()