from model.umbrales import Umbrales
from model.historial import Historial


NIVELES = {"Bueno": 0, "Moderado": 1, "Dañino": 2}


class LecturaActual:
    """Representa la última lectura procesada (no se persiste sola, ver Historial)."""

    def __init__(self, pm25, pm10, mq135, estado, detalle):
        self.pm25 = pm25
        self.pm10 = pm10
        self.mq135 = mq135
        self.estado = estado
        self.detalle = detalle  


class ModeloCalidadAire:
    """
    Mantiene el estado "en memoria" más reciente (para respuesta
    rápida del polling) y delega la persistencia a Historial.
    """

    def __init__(self):
        self.ultima_lectura = None  

    # ──────────────────────────────────────────
    # Clasificación
    # ──────────────────────────────────────────
    @staticmethod
    def _clasificar_valor(valor, umbral_bueno, umbral_moderado, umbral_dañino):
        if valor <= umbral_bueno:
            return "Bueno"
        elif valor <= umbral_moderado:
            return "Moderado"
        else:
            return "Dañino"

    def _clasificar(self, pm25, pm10, mq135):
        u = Umbrales.obtener_todos()

        estado_pm25 = self._clasificar_valor(
            pm25, u["pm25_bueno"], u["pm25_moderado"], u["pm25_dañino"]
        )
        estado_pm10 = self._clasificar_valor(
            pm10, u["pm10_bueno"], u["pm10_moderado"], u["pm10_dañino"]
        )
        estado_mq135 = self._clasificar_valor(
            mq135, u["mq135_bueno"], u["mq135_moderado"], u["mq135_dañino"]
        )

        detalle = {
            "pm25": estado_pm25,
            "pm10": estado_pm10,
            "mq135": estado_mq135,
        }

        
        estado_general = max(detalle.values(), key=lambda e: NIVELES[e])
        return estado_general, detalle

    # ──────────────────────────────────────────
    # Registro de una nueva lectura
    # ──────────────────────────────────────────
    def registrar_lectura(self, pm25, pm10, mq135):
        """
        Clasifica la lectura, la guarda en el historial (BD)
        y actualiza el estado "actual" en memoria.
        Retorna el objeto LecturaActual.
        """
        estado, detalle = self._clasificar(pm25, pm10, mq135)

        lectura = LecturaActual(pm25, pm10, mq135, estado, detalle)
        self.ultima_lectura = lectura

        # Persistir en BD (tabla historial)
        Historial.guardar(pm25, pm10, mq135, estado)

        return lectura

    # ──────────────────────────────────────────
    # Consultas para la API
    # ──────────────────────────────────────────
    def get_estado_actual(self):
        """
        Retorna un dict listo para jsonify con el estado actual.
        Si todavía no llegó ninguna lectura, retorna valores nulos.
        """
        if self.ultima_lectura is None:
            return {
                "pm25": None,
                "pm10": None,
                "mq135": None,
                "estado": "Sin datos",
                "detalle": {},
            }

        l = self.ultima_lectura
        return {
            "pm25": l.pm25,
            "pm10": l.pm10,
            "mq135": l.mq135,
            "estado": l.estado,
            "detalle": l.detalle,
        }

    def get_historial(self, limite=None):
        """Delega al modelo Historial (persistencia en BD)."""
        return Historial.obtener_recientes(limite)

    def reiniciar_historial(self):
        """Borra todos los registros del historial (función de administrador)."""
        Historial.limpiar()
        self.ultima_lectura = None
