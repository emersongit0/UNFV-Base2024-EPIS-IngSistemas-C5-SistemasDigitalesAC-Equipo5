import threading
import time
import random
import requests

URL_DESTINO = "http://127.0.0.1:5000/sensor-data"
INTERVALO_SEGUNDOS = 2


def _generar_lectura():
    """Genera valores plausibles, con variación ocasional hacia rangos altos."""
    if random.random() < 0.2:
        pm25 = random.uniform(40, 90)
        pm10 = random.uniform(80, 200)
        mq135 = random.randint(1800, 3500)
    else:
        pm25 = random.uniform(2, 30)
        pm10 = random.uniform(10, 60)
        mq135 = random.randint(300, 1500)

    return {
        "pm25": round(pm25, 1),
        "pm10": round(pm10, 1),
        "mq135": mq135,
    }


def _bucle_simulacion():
    while True:
        datos = _generar_lectura()
        try:
            requests.post(URL_DESTINO, json=datos, timeout=2)
        except requests.exceptions.RequestException as e:
            print(f"[mock_sensor] No se pudo enviar datos: {e}")
        time.sleep(INTERVALO_SEGUNDOS)


def iniciar_simulacion(en_hilo=True):
    """
    Inicia el envío periódico de datos simulados.
    en_hilo=True -> corre en background (no bloquea Flask).
    """
    if en_hilo:
        hilo = threading.Thread(target=_bucle_simulacion, daemon=True)
        hilo.start()
    else:
        _bucle_simulacion()
