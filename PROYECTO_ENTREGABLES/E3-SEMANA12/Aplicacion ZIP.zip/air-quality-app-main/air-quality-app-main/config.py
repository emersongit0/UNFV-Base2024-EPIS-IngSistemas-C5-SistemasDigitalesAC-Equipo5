import os

BASE_DIR = os.path.abspath(os.path.dirname(__file__))

# ──────────────────────────────────────────────
# Base de datos (SQLite)
# ──────────────────────────────────────────────
DB_PATH = os.path.join(BASE_DIR, "data", "airquality.db")

# ──────────────────────────────────────────────
# Seguridad de sesión
# ──────────────────────────────────────────────

SECRET_KEY = "cambia-esta-clave-en-produccion-unfv-2026"

# ──────────────────────────────────────────────
# Modo de operación
# ──────────────────────────────────────────────
# True  -> usa mock/mock_sensor.py para simular datos
# False -> espera datos reales del ESP32 vía POST /sensor-data
MODO_MOCK = False

# ──────────────────────────────────────────────
# Historial
# ──────────────────────────────────────────────
MAX_HISTORIAL = 50

# ──────────────────────────────────────────────
# Umbrales por defecto (se cargan en la BD la primera vez)
# Referencia: OMS (PM2.5/PM10) y rangos típicos MQ-135 (ADC 0-4095)
# ──────────────────────────────────────────────
UMBRALES_DEFAULT = {
    # PM2.5 (µg/m3)
    "pm25_bueno": 12.0,
    "pm25_moderado": 35.4,
    "pm25_dañino": 55.4,
    # PM10 (µg/m3)
    "pm10_bueno": 54.0,
    "pm10_moderado": 154.0,
    "pm10_dañino": 254.0,
    # MQ-135 (lectura ADC 0-4095)
    "mq135_bueno": 1000,
    "mq135_moderado": 2000,
    "mq135_dañino": 3000,
}

# Usuario administrador creado automáticamente si la BD está vacía
ADMIN_DEFAULT = {
    "username": "admin",
    "password": "admin123",  
    "rol": "admin",
}
