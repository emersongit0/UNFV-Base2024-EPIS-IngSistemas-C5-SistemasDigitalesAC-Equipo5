from flask import Flask

from config import SECRET_KEY, MODO_MOCK

from model.database import init_db
from model.air_quality import ModeloCalidadAire

from controllers.auth_controller import auth_bp
from controllers.sensor_controller import sensor_bp, init_sensor_controller
from controllers.historial_controller import historial_bp
from controllers.admin_controller import admin_bp, init_admin_controller

from mock.mock_sensor import iniciar_simulacion


app = Flask(__name__, template_folder="view/templates")
app.secret_key = SECRET_KEY



init_db()


# ──────────────────────────────────────────────
# Instancia única del modelo 
# ──────────────────────────────────────────────
modelo = ModeloCalidadAire()
init_sensor_controller(modelo)
init_admin_controller(modelo)


# ──────────────────────────────────────────────
# Registro de blueprints 
# ──────────────────────────────────────────────
app.register_blueprint(auth_bp)
app.register_blueprint(sensor_bp)
app.register_blueprint(historial_bp)
app.register_blueprint(admin_bp)


# ══════════════════════════════════════════════
# INICIO
# ══════════════════════════════════════════════

if __name__ == "__main__":
    if MODO_MOCK:
        print("=" * 50)
        print("  MODO DESARROLLO — datos simulados activos")
        print("  Cambia MODO_MOCK = False en config.py para usar ESP32 real")
        print("=" * 50)
        iniciar_simulacion(en_hilo=True)  

    app.run(host="0.0.0.0", port=5000, debug=False, use_reloader=False)
