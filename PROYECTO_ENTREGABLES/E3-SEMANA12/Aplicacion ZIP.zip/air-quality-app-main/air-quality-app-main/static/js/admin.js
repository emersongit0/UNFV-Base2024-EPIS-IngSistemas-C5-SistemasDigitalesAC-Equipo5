
document.addEventListener("DOMContentLoaded", () => {

    const formUmbrales =
        document.querySelector('form[action*="umbrales"]');

    if (!formUmbrales) return;

    formUmbrales.addEventListener("submit", (evento) => {

        const grupos = [
            ["pm25_bueno", "pm25_moderado"],
            ["pm10_bueno", "pm10_moderado"],
            ["mq135_bueno", "mq135_moderado"],
        ];

        for (const [bueno, moderado] of grupos) {

            const vBueno =
                parseFloat(document.getElementById(bueno).value);

            const vModerado =
                parseFloat(document.getElementById(moderado).value);

            if (!(vBueno < vModerado)) {

                evento.preventDefault();

                alert(
                    `Revisa los umbrales de "${bueno.split("_")[0].toUpperCase()}": ` +
                    `el límite "Bueno" debe ser menor que "Moderado".`
                );

                return;
            }
        }
    });

});


function actualizarDaninos() {

    document.getElementById("pm25_dañino").value =
        "> " + document.getElementById("pm25_moderado").value;

    document.getElementById("pm10_dañino").value =
        "> " + document.getElementById("pm10_moderado").value;

    document.getElementById("mq135_dañino").value =
        "> " + document.getElementById("mq135_moderado").value;
}

actualizarDaninos();

document.getElementById("pm25_moderado")
    .addEventListener("input", actualizarDaninos);

document.getElementById("pm10_moderado")
    .addEventListener("input", actualizarDaninos);

document.getElementById("mq135_moderado")
    .addEventListener("input", actualizarDaninos);