// static/js/historial.js

const REGISTROS_POR_PAGINA = 8;
let paginaActual = 1;
let todosLosRegistros = [];

function claseEstado(estado) {
    switch (estado) {
        case "Bueno":    return "bueno";
        case "Moderado": return "moderado";
        case "Dañino":   return "danino";
        default:         return "sin-datos";
    }
}

// ── Tabla con paginación ──
function llenarTabla(registros, pagina) {
    const cuerpo = document.getElementById("tabla-historial-body");
    if (!cuerpo) return;

    if (!registros || registros.length === 0) {
        cuerpo.innerHTML = "<tr><td colspan='5'>Sin registros aún.</td></tr>";
        return;
    }

    const filas = [...registros].reverse();
    const inicio = (pagina - 1) * REGISTROS_POR_PAGINA;
    const fin    = inicio + REGISTROS_POR_PAGINA;
    const pagina_filas = filas.slice(inicio, fin);

    cuerpo.innerHTML = pagina_filas.map((r) => `
        <tr>
            <td>${r.fecha}</td>
            <td>${Number(r.pm25).toFixed(1)}</td>
            <td>${Number(r.pm10).toFixed(1)}</td>
            <td>${r.mq135}</td>
            <td><span class="badge-estado ${claseEstado(r.estado)}">${r.estado}</span></td>
        </tr>
    `).join("");

    renderPaginacion(filas.length, pagina);
}

// ── Paginación dinámica ──
function renderPaginacion(total, pagina) {
    const contenedor = document.getElementById("paginacion");
    if (!contenedor) return;

    const totalPaginas = Math.ceil(total / REGISTROS_POR_PAGINA);
    if (totalPaginas <= 1) { contenedor.innerHTML = ""; return; }

    let html = `<button onclick="irPagina(${pagina - 1})" ${pagina === 1 ? "disabled" : ""}>←</button>`;

    for (let i = 1; i <= totalPaginas; i++) {
        if (
            i === 1 || i === totalPaginas ||
            (i >= pagina - 1 && i <= pagina + 1)
        ) {
            html += `<button onclick="irPagina(${i})" class="${i === pagina ? 'active' : ''}">${i}</button>`;
        } else if (i === pagina - 2 || i === pagina + 2) {
            html += `<button disabled>…</button>`;
        }
    }

    html += `<button onclick="irPagina(${pagina + 1})" ${pagina === totalPaginas ? "disabled" : ""}>→</button>`;
    contenedor.innerHTML = html;
}

function irPagina(pagina) {
    const totalPaginas = Math.ceil(todosLosRegistros.length / REGISTROS_POR_PAGINA);
    if (pagina < 1 || pagina > totalPaginas) return;
    paginaActual = pagina;
    llenarTabla(todosLosRegistros, paginaActual);
}

// ── Gráfico con PM2.5, PM10 y MQ-135 ──
function dibujarGrafico(registros) {
    const canvas = document.getElementById("grafico-historial");
    if (!canvas || !registros || registros.length === 0) return;

    // Últimos 50 registros
    const datos = registros.slice(-50);

    const ctx   = canvas.getContext("2d");
    const ancho = canvas.width  = canvas.clientWidth;
    const alto  = canvas.height = 300;

    ctx.clearRect(0, 0, ancho, alto);

    const padL = 45; const padR = ancho < 500 ? 90 : 160; const padT = 20, padB = 25;
    const grafW = ancho - padL - padR;
    const grafH = alto  - padT - padB;
    const n     = datos.length;

    const datosPm25  = datos.map(r => Number(r.pm25));
    const datosPm10  = datos.map(r => Number(r.pm10));
    const datosMq135 = datos.map(r => Number(r.mq135));

    const maxIzq = Math.max(...datosPm25, ...datosPm10, 10);
    const maxDer = Math.max(...datosMq135, 10);

    function puntoX(i) {
        return padL + (n === 1 ? grafW / 2 : (i * grafW) / (n - 1));
    }
    function puntoYizq(v) { return padT + grafH - (v / maxIzq) * grafH; }
    function puntoYder(v) { return padT + grafH - (v / maxDer) * grafH; }

    // Fondo cuadrícula
    ctx.strokeStyle = "#e9f2fb";
    ctx.lineWidth = 1;
    [0.25, 0.5, 0.75, 1].forEach(f => {
        const y = padT + grafH * (1 - f);
        ctx.beginPath();
        ctx.moveTo(padL, y);
        ctx.lineTo(ancho - padR, y);
        ctx.stroke();
        ctx.fillStyle = "#94a3b8";
        ctx.font = "11px sans-serif";
        ctx.fillText(Math.round(maxIzq * f), 2, y + 4);
    });

    // Eje derecho (MQ-135)
    [0.5, 1].forEach(f => {
        ctx.fillStyle = "#a78bfa";
        ctx.font = "11px sans-serif";
        ctx.fillText(Math.round(maxDer * f), ancho - padR + 6, padT + grafH * (1 - f) + 4);
    });

    // Ejes
    ctx.strokeStyle = "#d1e3f5";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(padL, padT);
    ctx.lineTo(padL, padT + grafH);
    ctx.lineTo(ancho - padR, padT + grafH);
    ctx.stroke();

    // Dibujar serie
    function serie(datos, color, yFn) {
        ctx.strokeStyle = color;
        ctx.lineWidth = 2;
        ctx.beginPath();
        datos.forEach((v, i) => {
            const x = puntoX(i), y = yFn(v);
            i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        });
        ctx.stroke();
    }

    serie(datosPm25,  "#2563eb", puntoYizq);
    serie(datosPm10,  "#ef4444", puntoYizq);
    serie(datosMq135, "#a855f7", puntoYder);

    // Leyenda
    const leyenda = [
        { label: "PM2.5 (µg/m³)",  color: "#2563eb" },
        { label: "PM10 (µg/m³)",   color: "#ef4444" },
        { label: "MQ-135 (ADC)",   color: "#a855f7" },
    ];
    ctx.font = ancho < 500 ? "bold 9px Arial" : "bold 13px Arial";
    leyenda.forEach((l, i) => {
        ctx.fillStyle = l.color;
        ctx.fillText("● " + l.label, ancho - padR + 8, padT + 20 + i * 22);
    });
}

// ── Carga ──
async function cargarHistorial() {
    const endpoint = (typeof ES_ADMIN !== "undefined" && ES_ADMIN)
        ? "/api/historial-completo"
        : "/api/historial";

    try {
        const respuesta = await fetch(endpoint);
        if (!respuesta.ok) return;
        todosLosRegistros = await respuesta.json();
        llenarTabla(todosLosRegistros, paginaActual);
        dibujarGrafico(todosLosRegistros);
    } catch (e) {
        console.error("Error cargando historial:", e);
    }
}

cargarHistorial();
setInterval(cargarHistorial, 5000);