// static/js/dashboard.js
// ──────────────────────────────────────────────
// VISTA (JS): polling cada 2s a /api/estado y
// actualización del DOM en dashboard.html y
// recomendaciones.html.
// ──────────────────────────────────────────────

const INTERVALO_POLLING_MS = 2000;

// Mapea el estado textual del backend a una clase CSS
function claseEstado(estado) {
    switch (estado) {
        case "Bueno": return "bueno";
        case "Moderado": return "moderado";
        case "Dañino": return "danino";
        default: return "sin-datos";
    }
}

// Íconos para el panel de alerta general
function iconoEstado(estado) {
    switch (estado) {
        case "Bueno": return "";
        case "Moderado": return "";
        case "Dañino": return "";
        default: return "";
    }
}

// Texto del panel de alerta general
function textoAlerta(estado) {
    switch (estado) {
        case "Bueno":
            return "Calidad del aire BUENA. No se requieren precauciones.";
        case "Moderado":
            return "Calidad del aire MODERADA. Grupos sensibles deben tener precaución.";
        case "Dañino":
            return "Calidad del aire DAÑINA. Evita actividades al aire libre.";
        default:
            return "Esperando datos del sensor...";
    }
}

// ──────────────────────────────────────────────
// Recomendaciones según el estado general
// ──────────────────────────────────────────────
const RECOMENDACIONES = {

    "Bueno": [
        {
            titulo: "Actividades al aire libre",
            texto: "Puedes realizar actividades sin restricciones."
        },
        {
            titulo: "Ventila tu hogar",
            texto: "Buen momento para ventilar tu hogar o centro de estudio."
        },
        {
            titulo: "Ejercicio al aire libre",
            texto: "Ideal para hacer ejercicio al aire libre."
        }
    ],

    "Moderado": [
        {
            titulo: "Reduce el esfuerzo prolongado",
            texto: "Personas sensibles deben tener precaución."
        },
        {
            titulo: "Usa mascarilla si es necesario",
            texto: "Considera usarla si eres sensible a la contaminación."
        },
        {
            titulo: "Limita la ventilación",
            texto: "Evita ventilar en horas de mayor tráfico."
        }
    ],

    "Dañino": [
        {
            titulo: "Evita actividades intensas",
            texto: "Especialmente ejercicio prolongado al aire libre."
        },
        {
            titulo: "Usa mascarilla",
            texto: "Idealmente FFP2 o N95 si debes salir."
        },
        {
            titulo: "Mantén puertas cerradas",
            texto: "Reduce la entrada de contaminantes."
        },
        {
            titulo: "Atención a tu salud",
            texto: "Busca ayuda médica si aparecen síntomas."
        }
    ],

    "Sin datos": [
        {
            titulo: "Esperando información",
            texto: "Aún no existen datos del sensor."
        }
    ]
};

// ──────────────────────────────────────────────
// Actualización del Dashboard (dashboard.html)
// ──────────────────────────────────────────────
function actualizarDashboard(data) {
    const elPm25 = document.getElementById("valor-pm25");
    const elPm10 = document.getElementById("valor-pm10");
    const elMq135 = document.getElementById("valor-mq135");

    // Si los elementos no existen, esta vista no es el dashboard
    if (!elPm25) return;

    elPm25.textContent = (data.pm25 !== null) ? data.pm25.toFixed(1) : "--";
    elPm10.textContent = (data.pm10 !== null) ? data.pm10.toFixed(1) : "--";
    elMq135.textContent = (data.mq135 !== null) ? data.mq135 : "--";

    const rPm25 = document.getElementById("resumen-pm25");
    const rPm10 = document.getElementById("resumen-pm10");
    const rMq135 = document.getElementById("resumen-mq135");

    if(rPm25)
      rPm25.textContent =
        (data.pm25 !== null)
            ? data.pm25.toFixed(1)
            : "--";

    if(rPm10)
      rPm10.textContent =
        (data.pm10 !== null)
            ? data.pm10.toFixed(1)
            : "--";

    if(rMq135)
      rMq135.textContent =
        (data.mq135 !== null)
            ? data.mq135
            : "--";

    const detalle = data.detalle || {};

    actualizarBadge("badge-pm25", detalle.pm25);
    actualizarBadge("badge-pm10", detalle.pm10);
    actualizarBadge("badge-mq135", detalle.mq135);
    actualizarBadge("badge-general", data.estado);

    // Panel de alerta general
    const panel = document.getElementById("alerta-panel");
    const icono = document.getElementById("alerta-icono");
    const texto = document.getElementById("alerta-texto");

    if (panel) {
        panel.className = "alerta-panel " + claseEstado(data.estado);
        icono.textContent = iconoEstado(data.estado);
        texto.textContent = textoAlerta(data.estado);
    }

    // Marca de tiempo
    const fechaEl = document.getElementById("ultima-actualizacion");
    if (fechaEl) {
        const ahora = new Date();
        fechaEl.textContent = "Última actualización: " + ahora.toLocaleTimeString();
    }
}

function actualizarBadge(idElemento, estado) {
    const el = document.getElementById(idElemento);
    if (!el) return;

    const clase = claseEstado(estado);
    el.className = "badge-estado " + clase;
    el.textContent = estado || "Sin datos";
}

// ──────────────────────────────────────────────
// Actualización de Recomendaciones (recomendaciones.html)
// ──────────────────────────────────────────────
function actualizarRecomendaciones(data) {
    const badge = document.getElementById("badge-estado-actual");
    const lista = document.getElementById("lista-recomendaciones");

    // Si no existen estos elementos, no estamos en la vista de recomendaciones
    if (!badge || !lista) return;

    const estado = data.estado || "Sin datos";
    const desc = {
      "Bueno": "Calidad del aire aceptable. No se requieren precauciones.",
      "Moderado": "Algunas personas sensibles pueden experimentar síntomas leves.",
      "Dañino": "Evita la exposición prolongada al aire exterior.",
      "Sin datos": "Esperando datos del sensor..."
    };

    const textoDesc = document.getElementById("texto-estado-desc");

    if(textoDesc){
       textoDesc.textContent = desc[estado];
    }

    badge.className = "badge-estado " + claseEstado(estado);
    badge.textContent = estado;

    const items = RECOMENDACIONES[estado] || RECOMENDACIONES["Sin datos"];

    lista.innerHTML = "";

    items.forEach((item) => {

       const li = document.createElement("li");

       li.innerHTML = `
          <div>
             <strong class="recom-titulo">
                ${item.titulo}
             </strong>

             <p class="recom-texto">
                ${item.texto}
             </p>
          </div>
      `;

       lista.appendChild(li);
    });
}

// ──────────────────────────────────────────────
// Polling principal
// ──────────────────────────────────────────────
async function consultarEstado() {
    try {
        const respuesta = await fetch("/api/estado");

        // Si la sesión expiró, el servidor redirige al login (HTML, no JSON)
        if (!respuesta.ok) return;

        const data = await respuesta.json();

        actualizarDashboard(data);
        actualizarRecomendaciones(data);
    } catch (error) {
        console.error("Error consultando /api/estado:", error);
    }
}

// Primera consulta inmediata + polling periódico
consultarEstado();
setInterval(consultarEstado, INTERVALO_POLLING_MS);
