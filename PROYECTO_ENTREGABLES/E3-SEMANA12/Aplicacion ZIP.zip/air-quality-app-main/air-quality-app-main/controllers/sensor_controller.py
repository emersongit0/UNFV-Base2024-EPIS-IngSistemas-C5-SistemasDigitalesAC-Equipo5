from flask import Blueprint, request, jsonify, render_template, session
from controllers.auth_controller import login_requerido

sensor_bp = Blueprint("sensor", __name__)

modelo = None


def init_sensor_controller(modelo_calidad_aire):
    """Permite que app.py inyecte la instancia única del modelo."""
    global modelo
    modelo = modelo_calidad_aire


# ══════════════════════════════════════════════
# VISTAS (HTML)
# ══════════════════════════════════════════════

@sensor_bp.route("/")
@sensor_bp.route("/dashboard")
@login_requerido
def dashboard():
    """Dashboard principal: datos en tiempo real, estado y alertas."""
    return render_template(
        "dashboard.html",
        username=session.get("username"),
        rol=session.get("rol"),
    )


@sensor_bp.route("/recomendaciones")
@login_requerido
def recomendaciones():
    """
    Página de recomendaciones de salud según el estado actual del aire.
    El contenido se calcula en el template/JS a partir de /api/estado.
    """
    return render_template(
        "recomendaciones.html",
        username=session.get("username"),
        rol=session.get("rol"),
    )


# ══════════════════════════════════════════════
# API — usada por el ESP32 y por el JS del dashboard
# ══════════════════════════════════════════════

@sensor_bp.route("/sensor-data", methods=["POST"])
def recibir_datos():
    """
    El ESP32 (o el simulador) llama a este endpoint periódicamente.
    Body JSON esperado:
    {
        "pm25": 35.4,
        "pm10": 67.2,
        "mq135": 1823
    }
    Este endpoint NO requiere login: el ESP32 no maneja sesiones.
    """
    datos = request.get_json(silent=True)

    if not datos:
        return jsonify({"error": "JSON inválido o vacío"}), 400

    if "mq135" not in datos:
        return jsonify({"error": "Campo mq135 faltante"}), 400
    datos.setdefault("pm25", 0)
    datos.setdefault("pm10", 0)

    lectura = modelo.registrar_lectura(
        pm25=float(datos["pm25"]),
        pm10=float(datos["pm10"]),
        mq135=int(datos["mq135"]),
    )

    return jsonify({"status": "ok", "estado": lectura.estado}), 200



@sensor_bp.route("/api/estado")
@login_requerido
def get_estado():
    """El dashboard JS consulta esto cada ~2s (polling)."""
    return jsonify(modelo.get_estado_actual())


@sensor_bp.route("/api/historial")
@login_requerido
def get_historial_reciente():
    """Últimas N lecturas para el gráfico (vista usuario)."""
    return jsonify(modelo.get_historial())

from model.umbrales import Umbrales

@sensor_bp.route("/api/umbrales")
def get_umbrales():

    u = Umbrales.obtener_todos()

    return jsonify({

        "pm25_bueno": u["pm25_bueno"],
        "pm25_moderado": u["pm25_moderado"],
        "pm25_danino": u["pm25_dañino"],

        "pm10_bueno": u["pm10_bueno"],
        "pm10_moderado": u["pm10_moderado"],
        "pm10_danino": u["pm10_dañino"],

        "mq135_bueno": u["mq135_bueno"],
        "mq135_moderado": u["mq135_moderado"],
        "mq135_danino": u["mq135_dañino"]
    })
