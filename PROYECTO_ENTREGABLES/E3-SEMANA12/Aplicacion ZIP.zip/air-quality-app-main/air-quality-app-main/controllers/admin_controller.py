from flask import Blueprint, render_template, request, jsonify, session, redirect, url_for, flash
from controllers.auth_controller import admin_requerido
from model.umbrales import Umbrales
from model.usuario import Usuario
from model.historial import Historial

admin_bp = Blueprint("admin", __name__)


modelo = None


def init_admin_controller(modelo_calidad_aire):
    global modelo
    modelo = modelo_calidad_aire


# ══════════════════════════════════════════════
# VISTA PRINCIPAL DEL PANEL
# ══════════════════════════════════════════════

@admin_bp.route("/admin")
@admin_requerido
def panel():
    """Panel de administración: umbrales + usuarios."""
    return render_template(
        "admin.html",
        username=session.get("username"),
        rol=session.get("rol"),
        umbrales=Umbrales.obtener_todos(),
        usuarios=Usuario.listar_todos(),
        total_registros=Historial.contar(),
    )


# ══════════════════════════════════════════════
# UMBRALES
# ══════════════════════════════════════════════

@admin_bp.route("/admin/umbrales", methods=["POST"])
@admin_requerido
def actualizar_umbrales():
    """
    Recibe el formulario de umbrales y actualiza la BD.

    El administrador solamente configura los límites
    'Bueno' y 'Moderado'.

    El nivel 'Dañino' se determina automáticamente para
    cualquier valor que supere el umbral moderado.
    """
    claves_esperadas = [
    "pm25_bueno",
    "pm25_moderado",

    "pm10_bueno",
    "pm10_moderado",

    "mq135_bueno",
    "mq135_moderado",
    ]

    nuevos_valores = {}
    for clave in claves_esperadas:
        valor = request.form.get(clave)
        if valor is not None:
            try:
                nuevos_valores[clave] = float(valor)
            except ValueError:
                flash(f"Valor inválido para {clave}.", "error")
                return redirect(url_for("admin.panel"))
            
    # PM2.5
    if nuevos_valores["pm25_bueno"] >= nuevos_valores["pm25_moderado"]:
        flash(
            "PM2.5: el límite 'Bueno' debe ser menor que 'Moderado'.",
            "error"
        )
        return redirect(url_for("admin.panel"))

    # PM10
    if nuevos_valores["pm10_bueno"] >= nuevos_valores["pm10_moderado"]:
        flash(
            "PM10: el límite 'Bueno' debe ser menor que 'Moderado'.",
            "error"
        )
        return redirect(url_for("admin.panel"))

    # MQ135
    if nuevos_valores["mq135_bueno"] >= nuevos_valores["mq135_moderado"]:
        flash(
            "MQ135: el límite 'Bueno' debe ser menor que 'Moderado'.",
            "error"
        )
        return redirect(url_for("admin.panel"))

    Umbrales.actualizar(nuevos_valores)
    flash("Umbrales actualizados correctamente.", "success")
    return redirect(url_for("admin.panel"))


# ══════════════════════════════════════════════
# GESTIÓN DE USUARIOS
# ══════════════════════════════════════════════

@admin_bp.route("/admin/usuarios", methods=["POST"])
@admin_requerido
def crear_usuario():
    """Crea un nuevo usuario (rol 'usuario' o 'admin')."""
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    rol = request.form.get("rol", "usuario")

    ok, mensaje = Usuario.crear(username, password, rol)
    flash(mensaje, "success" if ok else "error")
    return redirect(url_for("admin.panel"))


@admin_bp.route("/admin/usuarios/<int:user_id>/eliminar", methods=["POST"])
@admin_requerido
def eliminar_usuario(user_id):
    """Elimina un usuario por id."""
    ok, mensaje = Usuario.eliminar(user_id)

    if ok and user_id == session.get("user_id"):
        session.clear()
        return redirect(url_for("auth.login"))

    flash(mensaje, "success" if ok else "error")
    return redirect(url_for("admin.panel"))


@admin_bp.route("/admin/usuarios/<int:user_id>/rol", methods=["POST"])
@admin_requerido
def cambiar_rol(user_id):
    """
    Promueve o degrada a un usuario entre 'usuario' y 'admin'.
    Permite habilitar nuevos administradores sin tocar el backend
    (ej: alguien se registra en /registro y luego un admin lo promueve).
    """
    nuevo_rol = request.form.get("rol", "usuario")

    ok, mensaje = Usuario.cambiar_rol(user_id, nuevo_rol)
    flash(mensaje, "success" if ok else "error")
    return redirect(url_for("admin.panel"))


# ══════════════════════════════════════════════
# HISTORIAL
# ══════════════════════════════════════════════

@admin_bp.route("/admin/historial/reiniciar", methods=["POST"])
@admin_requerido
def reiniciar_historial():
    """Borra todo el historial de lecturas almacenado."""
    modelo.reiniciar_historial()
    flash("Historial reiniciado correctamente.", "success")
    return redirect(url_for("admin.panel"))
