from flask import Blueprint, render_template, jsonify, session
from controllers.auth_controller import login_requerido, admin_requerido
from model.historial import Historial

historial_bp = Blueprint("historial", __name__)


@historial_bp.route("/historial")
@login_requerido
def ver_historial():
    """Página con tabla y gráfico del historial reciente."""
    return render_template(
        "historial.html",
        username=session.get("username"),
        rol=session.get("rol"),
    )


@historial_bp.route("/api/historial-completo")
@admin_requerido
def historial_completo():
    """
    Retorna TODOS los registros guardados (sin límite).
    Solo accesible para administradores -> 'Ver todos los registros'.
    """
    return jsonify(Historial.obtener_todos())
