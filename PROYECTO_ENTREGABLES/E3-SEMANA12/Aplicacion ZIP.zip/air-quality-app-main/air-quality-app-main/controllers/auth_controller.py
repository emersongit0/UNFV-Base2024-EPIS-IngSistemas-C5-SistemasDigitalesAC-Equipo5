from functools import wraps
from flask import (
    Blueprint, render_template, request, redirect,
    url_for, session, flash
)
from model.usuario import Usuario

auth_bp = Blueprint("auth", __name__)


# ══════════════════════════════════════════════
# DECORADORES DE PROTECCIÓN DE RUTAS
# ══════════════════════════════════════════════

def login_requerido(vista):
    """Bloquea el acceso si no hay sesión activa."""
    @wraps(vista)
    def envoltura(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("auth.login"))
        return vista(*args, **kwargs)
    return envoltura


def admin_requerido(vista):
    """Bloquea el acceso si el usuario no tiene rol 'admin'."""
    @wraps(vista)
    def envoltura(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("auth.login"))
        if session.get("rol") != "admin":
            flash("No tienes permisos para acceder a esa sección.", "error")
            return redirect(url_for("sensor.dashboard"))
        return vista(*args, **kwargs)
    return envoltura


# ══════════════════════════════════════════════
# RUTAS
# ══════════════════════════════════════════════

@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    """Formulario de inicio de sesión."""
    if "user_id" in session:
        return redirect(url_for("sensor.dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")

        usuario = Usuario.autenticar(username, password)

        if usuario is None:
            flash("Usuario o contraseña incorrectos.", "error")
            return render_template("login.html")

        session["user_id"] = usuario.id
        session["username"] = usuario.username
        session["rol"] = usuario.rol

        return redirect(url_for("sensor.dashboard"))

    return render_template("login.html")


@auth_bp.route("/logout")
def logout():
    """Cierra la sesión actual."""
    session.clear()
    return redirect(url_for("auth.login"))


@auth_bp.route("/registro", methods=["GET", "POST"])
def registro():
    """
    Registro público de nuevos usuarios.
    Siempre se crean con rol 'usuario' — para volverse admin,
    un administrador debe editar el rol desde el panel /admin.
    """
    if "user_id" in session:
        return redirect(url_for("sensor.dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        password2 = request.form.get("password2", "")

        if not username or not password:
            flash("Usuario y contraseña son obligatorios.", "error")
            return render_template("registro.html")

        if password != password2:
            flash("Las contraseñas no coinciden.", "error")
            return render_template("registro.html")

        if len(password) < 4:
            flash("La contraseña debe tener al menos 4 caracteres.", "error")
            return render_template("registro.html")

        ok, mensaje = Usuario.crear(username, password, rol="usuario")

        if not ok:
            flash(mensaje, "error")
            return render_template("registro.html")

        flash("Cuenta creada correctamente. Ya puedes iniciar sesión.", "success")
        return redirect(url_for("auth.login"))

    return render_template("registro.html")
