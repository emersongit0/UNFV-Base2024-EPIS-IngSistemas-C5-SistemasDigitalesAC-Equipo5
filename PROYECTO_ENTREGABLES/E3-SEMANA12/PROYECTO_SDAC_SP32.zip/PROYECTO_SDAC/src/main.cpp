#include <Arduino.h>
#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

// ======================
// WIFI
// ======================

const char* ssid = "Rwawas";
const char* password = "emerson3113";

const char* serverUrl =
    "http://10.76.186.245:5000/sensor-data";

const char* umbralesUrl =
    "http://10.76.186.245:5000/api/umbrales";

// ======================
// PINES
// ======================

#define MQ135_PIN 35

#define LED_VERDE 18
#define LED_AMARILLO 19
#define LED_ROJO 23

#define BUZZER 5

// SDS011

HardwareSerial SDS(2);

// ======================
// VARIABLES SDS011
// ======================

float pm25 = 0.0;
float pm10 = 0.0;
int valorMQ = 0;

// ======================
// UMBRALES DINÁMICOS
// ======================

// PM2.5

float pm25_bueno = 12.0;
float pm25_moderado = 35.4;
float pm25_danino = 55.4;

// PM10

float pm10_bueno = 54.0;
float pm10_moderado = 154.0;
float pm10_danino = 254.0;

// MQ135

float mq135_bueno = 1000;
float mq135_moderado = 2000;
float mq135_danino = 3000;

// ======================
// ESTADOS
// ======================

enum EstadoAire
{
    NORMAL,
    PREVENTIVO,
    CRITICO
};

EstadoAire estadoActual;

// ======================
// REFRESH UMBRALES
// ======================

unsigned long ultimoRefresh = 0;
const unsigned long intervaloRefresh = 2000;

// ======================
// WIFI
// ======================

void conectarWiFi()
{
    Serial.print("Conectando a WiFi");

    WiFi.begin(ssid, password);

    while (WiFi.status() != WL_CONNECTED)
    {
        delay(500);
        Serial.print(".");
    }

    Serial.println();
    Serial.println("WiFi conectado");

    Serial.print("IP ESP32: ");
    Serial.println(WiFi.localIP());
}

// ======================
// CLASIFICADOR
// ======================

int clasificarValor(
    float valor,
    float bueno,
    float moderado)
{
    if (valor <= bueno)
        return 0;

    if (valor <= moderado)
        return 1;

    return 2;
}

// ======================
// DESCARGAR UMBRALES
// ======================

void obtenerUmbrales()
{
    if (WiFi.status() != WL_CONNECTED)
        return;

    HTTPClient http;

    http.begin(umbralesUrl);

    int codigo = http.GET();

    Serial.print("GET Umbrales: ");
    Serial.println(codigo);

    if (codigo == 200)
    {
        String payload = http.getString();

        DynamicJsonDocument doc(1024);

        DeserializationError error =
            deserializeJson(doc, payload);

        if (!error)
        {
            pm25_bueno =
                doc["pm25_bueno"];

            pm25_moderado =
                doc["pm25_moderado"];

            pm25_danino =
                doc["pm25_danino"];

            pm10_bueno =
                doc["pm10_bueno"];

            pm10_moderado =
                doc["pm10_moderado"];

            pm10_danino =
                doc["pm10_danino"];

            mq135_bueno =
                doc["mq135_bueno"];

            mq135_moderado =
                doc["mq135_moderado"];

            mq135_danino =
                doc["mq135_danino"];

            Serial.println("Umbrales actualizados");
        }
    }

    http.end();
}

// ======================
// ACTUADORES
// ======================

void actualizarActuadores(
    EstadoAire estado)
{
    switch (estado)
    {
    case NORMAL:

        digitalWrite(LED_VERDE, HIGH);
        digitalWrite(LED_AMARILLO, LOW);
        digitalWrite(LED_ROJO, LOW);

        digitalWrite(BUZZER, HIGH);

        break;

    case PREVENTIVO:

        digitalWrite(LED_VERDE, LOW);
        digitalWrite(LED_AMARILLO, HIGH);
        digitalWrite(LED_ROJO, LOW);

        digitalWrite(BUZZER, HIGH);

        break;

    case CRITICO:

        digitalWrite(LED_VERDE, LOW);
        digitalWrite(LED_AMARILLO, LOW);
        digitalWrite(LED_ROJO, HIGH);

        digitalWrite(BUZZER, LOW);

        break;
    }
}

// ======================
// LEER SDS011
// ======================

void leerSDS011()
{
    uint8_t buffer[10];

    while (SDS.available() >= 10)
    {
        SDS.readBytes(buffer, 10);
    }

    if (
        buffer[0] == 0xAA &&
        buffer[1] == 0xC0 &&
        buffer[9] == 0xAB)
    {
        pm25 =
            (buffer[2] +
             buffer[3] * 256) / 10.0;

        pm10 =
            (buffer[4] +
             buffer[5] * 256) / 10.0;
    }
}

// ======================
// ENVIAR DATOS
// ======================

void enviarDatos(
    float pm25,
    float pm10,
    int mq135)
{
    if (WiFi.status() != WL_CONNECTED)
        return;

    HTTPClient http;

    http.begin(serverUrl);

    http.addHeader(
        "Content-Type",
        "application/json");

    String json = "{";
    json += "\"pm25\":" + String(pm25) + ",";
    json += "\"pm10\":" + String(pm10) + ",";
    json += "\"mq135\":" + String(mq135);
    json += "}";

    int codigo =
        http.POST(json);

    Serial.print("HTTP: ");
    Serial.println(codigo);

    if (codigo > 0)
    {
        String respuesta =
            http.getString();

        Serial.println("Respuesta:");
        Serial.println(respuesta);
    }

    http.end();
}

// ======================
// SETUP
// ======================

void setup()
{
    Serial.begin(115200);

    SDS.begin(
        9600,
        SERIAL_8N1,
        16,
        17);

    pinMode(LED_VERDE, OUTPUT);
    pinMode(LED_AMARILLO, OUTPUT);
    pinMode(LED_ROJO, OUTPUT);

    pinMode(BUZZER, OUTPUT);

    digitalWrite(BUZZER, HIGH);

    conectarWiFi();

    obtenerUmbrales();

    ultimoRefresh = millis();

    Serial.println("Sistema iniciado");
}

// ======================
// LOOP
// ======================

void loop()
{

    if (
        millis() - ultimoRefresh >=
        intervaloRefresh)
    {
        Serial.println();
        Serial.println(
            "Actualizando umbrales...");

        obtenerUmbrales();

        ultimoRefresh = millis();

        Serial.println(
            "Actualizacion completada");
        Serial.println();
    }

    leerSDS011();

    valorMQ =
        analogRead(MQ135_PIN);

    int estadoPM25 =
        clasificarValor(
            pm25,
            pm25_bueno,
            pm25_moderado);

    int estadoPM10 =
        clasificarValor(
            pm10,
            pm10_bueno,
            pm10_moderado);

    int estadoMQ135 =
        clasificarValor(
            valorMQ,
            mq135_bueno,
            mq135_moderado);

    int peorEstado =
        max(
            estadoPM25,
            max(
                estadoPM10,
                estadoMQ135));

    switch (peorEstado)
    {
    case 0:
        estadoActual = NORMAL;
        break;

    case 1:
        estadoActual = PREVENTIVO;
        break;

    case 2:
        estadoActual = CRITICO;
        break;
    }

    actualizarActuadores(
        estadoActual);

    Serial.println();
    Serial.println("================================================");
    Serial.println("         SISTEMA DE MONITOREO DE CALIDAD DEL AIRE");
    Serial.println("================================================");

    Serial.print("MQ135        : ");
    Serial.println(valorMQ);

    Serial.print("PM2.5        : ");
    Serial.print(pm25);
    Serial.println(" ug/m3");

    Serial.print("PM10         : ");
    Serial.print(pm10);
    Serial.println(" ug/m3");

    Serial.print("Estado       : ");

    switch (estadoActual)
    {
        case NORMAL:
            Serial.println("NORMAL");
            break;

        case PREVENTIVO:
            Serial.println("PREVENTIVO");
            break;

        case CRITICO:
            Serial.println("CRITICO");
            break;
    }

    Serial.print("WiFi         : ");

    if (WiFi.status() == WL_CONNECTED)
    {
        Serial.println("CONECTADO");
    }
    else
    {
        Serial.println("DESCONECTADO");
    }

    Serial.print("Bytes disponibles: ");
    Serial.println(SDS.available());

    Serial.println("================================================");
    enviarDatos(
        pm25,
        pm10,
        valorMQ);

    Serial.println("----------------------");

    delay(2000);
}